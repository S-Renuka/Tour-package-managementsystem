<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "tourpackage"; // Your database name

$conn = new mysqli($host, $user, $password, $database);

// Check DB connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$package = $_POST['package'] ?? '';
$new_price = $_POST['new_price'] ?? '';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Price Update Result</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(120deg, #c2e9fb, #a1c4fd);
      margin: 0;
      padding: 40px;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .message-box {
      background-color: white;
      border-radius: 12px;
      padding: 40px;
      max-width: 500px;
      width: 100%;
      box-shadow: 0 10px 20px rgba(0,0,0,0.15);
      text-align: center;
    }

    .success {
      color: green;
      font-weight: bold;
      font-size: 20px;
    }

    .error {
      color: red;
      font-weight: bold;
      font-size: 18px;
    }

    button {
      margin-top: 30px;
      padding: 12px 24px;
      background-color: #0073e6;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #005bb5;
    }
  </style>
</head>
<body>

<div class="message-box">
  <?php
  if ($package && is_numeric($new_price)) {
      $stmt = $conn->prepare("UPDATE packages SET price = ? WHERE name = ?");
      $stmt->bind_param("ds", $new_price, $package);

      if ($stmt->execute()) {
          echo "<div class='success'>✅ Success!<br>The price for <strong>$package</strong> has been updated to ₹<strong>$new_price</strong>.</div>";
      } else {
          echo "<div class='error'>❌ Error updating price. Please try again later.</div>";
      }

      $stmt->close();
  } else {
      echo "<div class='error'⚠️ Invalid input. Please check your data.</div>";
  }

  $conn->close();
  ?>

  <button onclick="location.href='Home.html'">⬅ Go Back</button>
</div>

</body>
</html>
