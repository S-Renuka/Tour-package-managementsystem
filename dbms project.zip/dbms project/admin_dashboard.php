<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "tourpackage");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve all bookings
$sql = "SELECT * FROM bookings";
$result = $conn->query($sql);
?>

	<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - Tour Management</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #eef2f5;
    }

    header {
      background-color: #003366;
      color: white;
      padding: 20px;
      text-align: center;
    }

    nav {
      background-color: #004d99;
      display: flex;
      justify-content: center;
      padding: 10px 0;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
      font-weight: bold;
    }

    nav a:hover, nav a.active {
      text-decoration: underline;
    }

    .sidebar {
      width: 220px;
      background-color: #004080;
      position: fixed;
      top: 120px;
      bottom: 0;
      padding-top: 20px;
    }

    .sidebar a {
      display: block;
      padding: 15px 20px;
      color: white;
      text-decoration: none;
    }

    .sidebar a:hover {
      background-color: #0066cc;
    }

    .main-content {
      margin-left: 220px;
      padding: 30px;
      margin-top: 60px;
    }

    .dashboard-box {
      background-color: white;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .dashboard-box h3 {
      margin-top: 0;
      color: #003366;
    }

    footer {
      background-color: #003366;
      color: white;
      text-align: center;
      padding: 15px;
      margin-left: 220px;
    }
  </style>
</head>
<body>

<header>
  <h1>Admin Dashboard - Tour Package Management</h1>
</header>

<!-- Navigation Bar -->
<nav>
  <a href="Home.html">Home</a>
  <a href="Browsepackage.html">Browse Packages</a>
  <a href="itineraries.html">Itineraries</a>
  <a href="booknow.html">Book Now</a>
  <a href="contact.html">Contact Us</a>
  <a href="admin.html" class="active">Admin Panel</a>
</nav>

<!-- Sidebar -->
<div class="sidebar">
  <a href="admin_dashboard.php">Dashboard</a>
  <a href="view_bookings.php">View Bookings</a>
  <a href="update-pricing.html">Update Pricing</a>
  <a href="logout.html">Logout</a>
</div>

<!-- Main Content -->
<div class="main-content">
  <div class="dashboard-box">
    <h3>Welcome, Admin!</h3>
    <p>Use the sidebar to manage packages, bookings, customers, and more.</p>
  </div>

    <?php
    // Check if there are any rows in the result set
    if ($result->num_rows > 0) {
        // Start the table
        echo "<table border='1' cellpadding='10' cellspacing='0'>";
        echo "<tr>
                <th>ID</th>
                <th>Package</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Phone No</th>
                <th>Travel Date</th>
                <th>No. of People</th>
                <th>Special Requests</th>
                <th>Booking Time</th>
              </tr>";
        
        // Loop through the result set and display data
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['package'] . "</td>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . $row['email'] . "</td>";
            echo "<td>" . $row['phone'] . "</td>";
            echo "<td>" . $row['travel_date'] . "</td>";
            echo "<td>" . $row['people'] . "</td>";
            echo "<td>" . $row['special_requests'] . "</td>";
            echo "<td>" . $row['booking_time'] . "</td>";
            echo "</tr>";
        }

        // End the table
        echo "</table>";
    } else {
        echo "<p>No bookings found</p>";
    }

    // Close the connection
    $conn->close();
    ?>
</div>

</body>
</html>
