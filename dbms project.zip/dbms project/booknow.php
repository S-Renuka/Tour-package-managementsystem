<?php
// Database connection settings
$host = "localhost";
$user = "root";
$password = "";
$database = "tourpackage";

// Create a connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$package = $_POST['package'] ?? '';
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$travel_date = $_POST['travel_date'] ?? '';
$people = (int)($_POST['people'] ?? 0);
$requests = $_POST['requests'] ?? '';

// Package pricing (for example)
$prices = [
    "Goa" => 5000,
    "Paris" => 12000,
    "Delhi" => 4000,
    "Bali" => 8000,
    "Istanbul" => 9000,
    "New York" => 15000,
    "Singapore" => 11000,
    "Tokyo" => 14000,
    "Sydney" => 13000,
    "Kashmir" => 6000
];

// Calculate total
$price_per_person = $prices[$package] ?? 0;
$total = $price_per_person * $people;

// Validate required fields
if (!$package || !$name || !$email || !$phone || !$travel_date || $people <= 0 || $total == 0) {
    die("<h3>Error: Please fill in all required fields correctly.</h3>");
}

// Insert booking into database
$stmt = $conn->prepare("INSERT INTO bookings (package, name, email, phone, travel_date, people, total_amount, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssdss", $package, $name, $email, $phone, $travel_date, $people, $total, $requests);

if ($stmt->execute()) {
    // Redirect to payment page with booking info
    header("Location: payment.php?name=" . urlencode($name) . "&amount=" . urlencode($total));
    exit();
} else {
    echo "<h3>Booking failed. Please try again.</h3>";
}

$stmt->close();
$conn->close();
?>
