<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment - Tour Package Management</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #eef2f3;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #003366;
      color: white;
      padding: 20px;
      text-align: center;
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      background-color: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #003366;
      margin-bottom: 30px;
    }

    .payment-section {
      display: flex;
      justify-content: space-around;
      align-items: flex-start;
      gap: 40px;
      flex-wrap: wrap;
    }

    .qr-code {
      text-align: center;
    }

    .qr-code img {
      width: 150px;
      height: auto;
      border: 1px solid #ccc;
      border-radius: 10px;
    }

    form {
      flex: 1;
      min-width: 250px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: bold;
    }

    input[type="file"],
    input[type="text"],
    input[type="tel"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .btn {
      width: 100%;
      padding: 12px;
      background-color: #003366;
      color: white;
      font-size: 16px;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }

    .btn:hover {
      background-color: #002244;
    }

    footer {
      background-color: #003366;
      color: white;
      text-align: center;
      padding: 15px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

<header>
  <h1>Payment Portal</h1>
</header>

<div class="container">
  <h2>Scan or Upload Payment Proof</h2>

  <div class="payment-section">
    <!-- Left: QR Code -->
    <div class="qr-code">
      <p style="font-weight: bold;">Scan to Pay</p>
      <img src="qrcode.jpg" alt="QR Code for Payment">
    </div>

    <!-- Right: Upload Form -->
    <form action="paymentsuccess.php" method="POST" enctype="multipart/form-data">
      <label for="name">Full Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="phone">Phone Number:</label>
      <input type="tel" id="phone" name="phone" required>

      <label for="payment_proof">Upload Payment Screenshot:</label>
      <input type="file" id="payment_proof" name="payment_proof" accept="image/*" required>

      <button type="submit" class="btn">Upload and Proceed</button>
    </form>
  </div>
</div>

<footer>
  &copy; 2025 Tour Package Management System. All rights reserved.
</footer>

</body>
</html>
