<?php
$conn = new mysqli("localhost", "root", "", "tourpackage");
$result = $conn->query("SELECT * FROM payment_proofs");

echo "<h2>Uploaded Payment Screenshots</h2>";
while ($row = $result->fetch_assoc()) {
    echo "<div style='margin-bottom:20px; border:1px solid #ccc; padding:10px'>";
    echo "<strong>Name:</strong> " . htmlspecialchars($row['name']) . "<br>";
    echo "<strong>Phone:</strong> " . htmlspecialchars($row['phone']) . "<br>";
    echo "<img src='uploads/" . htmlspecialchars($row['filename']) . "' width='300'><br>";
    echo "<small>Uploaded on: " . $row['upload_time'] . "</small>";
    echo "</div>";
}
$conn->close();
?>
