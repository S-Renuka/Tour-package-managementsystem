<?php
session_start();
$conn = new mysqli("localhost", "root", "", "tourpackage");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Prepare and query the database
$stmt = $conn->prepare("SELECT * FROM admins WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $_SESSION['admin'] = true;
    header("Location: admin_dashboard.php");
    exit();
} else {
    echo "<script>alert('Invalid username or password'); window.location.href = 'admin_login.php';</script>";
    exit();
}
?>
