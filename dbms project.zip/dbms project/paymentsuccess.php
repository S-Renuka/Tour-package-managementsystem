<?php
session_start();
$conn = new mysqli("localhost", "root", "", "tourpackage");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get session values
$name = $_SESSION['name'] ?? '';
$phone = $_SESSION['phone'] ?? '';

$uploadDir = "uploads/";
$originalName = basename($_FILES["payment_proof"]["name"]);
$targetFile = $uploadDir . time() . "_" . $originalName;

if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $targetFile)) {
    $fileName = basename($targetFile);

    // Save into payment_proofs table
    $stmt = $conn->prepare("INSERT INTO payment_proofs (filename, name, phone) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $fileName, $name, $phone);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header("Location: paymentsuccess.html");
    exit();
} else {
    echo "Error uploading the payment proof.";
}
?>
