<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "tourpackage");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT name, price, description, image FROM packages");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Browse Packages - Tour Management</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f8fc;
    }

    header {
      background-color: #0066cc;
      color: white;
      padding: 30px;
      text-align: center;
    }

    nav {
      background-color: #004d99;
      display: flex;
      justify-content: center;
      padding: 10px 0;
    }

    nav a {
      color: white;
      margin: 0 15px;
      text-decoration: none;
      font-weight: bold;
    }

    nav a:hover {
      text-decoration: underline;
    }

    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 20px;
    }

    h2 {
      text-align: center;
      color: #003366;
    }

    .packages {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 25px;
      margin-top: 30px;
    }

    .card {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      overflow: hidden;
      transition: transform 0.2s;
    }

    .card:hover {
      transform: scale(1.03);
    }

    .card img {
      width: 100%;
      height: 180px;
      object-fit: cover;
    }

    .card-content {
      padding: 15px;
    }

    .card-content h3 {
      margin-top: 0;
      color: #0066cc;
    }

    .card-content p {
      font-size: 14px;
      color: #333;
    }

    .card-content a {
      display: inline-block;
      margin-top: 10px;
      padding: 10px 15px;
      background-color: #0066cc;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }

    .card-content a:hover {
      background-color: #004d99;
    }

    footer {
      background-color: #003366;
      color: white;
      text-align: center;
      padding: 15px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

<header>
  <h1>Browse Tour Packages</h1>
</header>

<nav>
  <a href="Home.html">Home</a>
  <a href="Browsepackage.html">Browse Packages</a>
  <a href="itineraries.html">Itineraries</a>
  <a href="booknow.html">Book Now</a>
  <a href="contact.html">Contact Us</a>
  <a href="admin.html">Admin Panel</a>
</nav>

<div class="container">
  <h2>Explore Our Top Destinations</h2>

  <div class="packages">
    <?php
      while($row = $result->fetch_assoc()) {
        echo '
        <div class="card">
          <img src="images/' . $row['image'] . '" alt="' . $row['name'] . '">
          <div class="card-content">
            <h3>' . $row['name'] . '</h3>
            <p>' . $row['description'] . '</p>
            <p><strong>Package: ₹' . $row['price'] . '</strong></p>
            <a href="itineraries.html">View Details</a>
          </div>
        </div>';
      }
      $conn->close();
    ?>
  </div>
</div>

<footer>
  &copy; 2025 Tour Package Management System. All rights reserved.
</footer>

</body>
</html>
